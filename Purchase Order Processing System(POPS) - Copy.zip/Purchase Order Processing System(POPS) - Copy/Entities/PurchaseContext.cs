﻿using Microsoft.EntityFrameworkCore;

namespace Purchase_Order_Processing_System_POPS_.Entities
{
    public class PurchaseContext:DbContext
    {
        private IConfiguration _configuration;

        public PurchaseContext(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public DbSet<SUPPLIER> Suppliers { get; set; }
        public DbSet<Item> Items { get; set; }
        public DbSet<POMASTER> POMASTERs { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {

           
            optionsBuilder.UseSqlServer(_configuration.GetConnectionString("PurchaseConnection"));

        }
    }
}
