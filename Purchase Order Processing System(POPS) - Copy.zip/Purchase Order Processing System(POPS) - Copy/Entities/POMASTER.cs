﻿using static Purchase_Order_Processing_System_POPS_.Entities.SUPPLIER;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace Purchase_Order_Processing_System_POPS_.Entities
{
    public class POMASTER
    {

        [Key]
        public string PoNo { get; set; }
        public DateTime PoDate { get; set; }

        [ForeignKey("Item")]
        public string ItCode { get; set; }
        [JsonIgnore]
        public Item? Item { get; set; }

        [ForeignKey("SUPPLIER")]
        public string SuplNo { get; set; }
        [JsonIgnore]
        public SUPPLIER? Supplier { get; set; }

        public int Qty { get; set; }
    }

}

