﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Purchase_Order_Processing_System_POPS_.Entities
{
    public class SUPPLIER
    {
        
        
            [Key]
            public string SuplNo { get; set; }
            public string SuplName { get; set; }
            public string SuplAddr { get; set; }


        

    }
}
        

        
    

