﻿using System.ComponentModel.DataAnnotations;

namespace Purchase_Order_Processing_System_POPS_.Entities
{
    public class Item
    {
        [Key]
        public string ItCode { get; set; }
        public string ItDesc { get; set; }
        public int ItRate { get; set; }
    }
}
