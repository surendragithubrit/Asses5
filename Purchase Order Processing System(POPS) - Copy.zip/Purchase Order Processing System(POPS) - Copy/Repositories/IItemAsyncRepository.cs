﻿using Purchase_Order_Processing_System_POPS_.Entities;

namespace Purchase_Order_Processing_System_POPS_.Repositories
{
    public interface IItemAsyncRepository
    {
        Task<List<Item>> GetAll();
        Task<Item> GetById(string id);
        Task Update(Item item);
        Task DeleteById(string id);
        Task Add(Item item);
    }
}
