﻿using Microsoft.EntityFrameworkCore;
using Purchase_Order_Processing_System_POPS_.Entities;
using Purchase_Order_Processing_System_POPS_.Repositories;


namespace Purchase_Order_Processing_System_POPS_.Repositories
{
    public class POMASTERAsyncRepository : IPOMASTERAsyncRepository
    {
        private readonly PurchaseContext _purchaseContext;
        public async Task Add(POMASTER pOMASTER)
        {
            _purchaseContext.POMASTERs.Add(pOMASTER);
            await _purchaseContext.SaveChangesAsync();
        }

        public async Task DeleteById(string id)
        {
            var pOMASTER = await _purchaseContext.POMASTERs.FindAsync(id);
            _purchaseContext.POMASTERs.Remove(pOMASTER);
            await _purchaseContext.SaveChangesAsync();
        }

        public async  Task<List<POMASTER>> GetAll()
        {
            return await _purchaseContext.POMASTERs.ToListAsync();
        }

        public async Task<POMASTER> GetById(string id)
        {
            return await _purchaseContext.POMASTERs.SingleOrDefaultAsync(s => s.ItCode == id);
        }

        public async Task Update(POMASTER pOMASTER)
        {
            _purchaseContext.POMASTERs.Update(pOMASTER);
            await _purchaseContext.SaveChangesAsync();
        }
    }
}
