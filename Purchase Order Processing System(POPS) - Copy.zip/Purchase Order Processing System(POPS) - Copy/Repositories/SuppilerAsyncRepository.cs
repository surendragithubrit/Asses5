﻿using Microsoft.EntityFrameworkCore;
using Purchase_Order_Processing_System_POPS_.Entities;

namespace Purchase_Order_Processing_System_POPS_.Controllers
{
    public class SuppilerAsyncRepository : ISuppilerAsyncRepository
    {
        private readonly PurchaseContext _purchaseContext;

        public SuppilerAsyncRepository(PurchaseContext purchaseContext)
        {
            _purchaseContext = purchaseContext;
        }

        public async Task Add(SUPPLIER supplier)
        {
            _purchaseContext.Suppliers.Add(supplier);
            await _purchaseContext.SaveChangesAsync();
        }

        public async Task DeleteById(string id)
        {
            var supplier = await _purchaseContext.Suppliers.FindAsync(id);
            _purchaseContext.Suppliers.Remove(supplier);
            await _purchaseContext.SaveChangesAsync();

        }

        public async Task<List<SUPPLIER>> GetAll()
        {
            return await _purchaseContext.Suppliers.ToListAsync();
        }


        public async Task<SUPPLIER> GetById(string id)
        {
            return await _purchaseContext.Suppliers.SingleOrDefaultAsync(s => s.SuplNo == id);
        }


        public async Task Update(SUPPLIER supplier)
        {
            _purchaseContext.Suppliers.Update(supplier);
            await _purchaseContext.SaveChangesAsync();
        }

    }

}

