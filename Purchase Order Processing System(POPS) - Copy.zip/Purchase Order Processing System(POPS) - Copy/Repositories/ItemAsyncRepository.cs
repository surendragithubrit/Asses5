﻿using Purchase_Order_Processing_System_POPS_.Entities;
using Purchase_Order_Processing_System_POPS_.Repositories;
using Purchase_Order_Processing_System_POPS_.Entities;
using Microsoft.EntityFrameworkCore;
using System.Reflection.Emit;


namespace Purchase_Order_Processing_System_POPS_.Repositories
{
    
    public class ItemAsyncRepository : IItemAsyncRepository
    {
        private readonly PurchaseContext _purchaseContext;

        public ItemAsyncRepository(PurchaseContext purchaseContext)
        {
            _purchaseContext = purchaseContext;
        }

        public async Task Add(Item item)
        {
            _purchaseContext.Items.Add(item);
            await _purchaseContext.SaveChangesAsync();
        }

        public async Task DeleteById(string id)
        {
            var item = await _purchaseContext.Items.FindAsync(id);
            _purchaseContext.Items.Remove(item);
            await _purchaseContext.SaveChangesAsync();
        }

        public async Task<List<Item>> GetAll()
        {
            return await _purchaseContext.Items.ToListAsync();
        }

        public async Task<Item> GetById(string id)
        {
            return await _purchaseContext.Items.SingleOrDefaultAsync(s => s.ItCode == id);
        }

        public async Task Update(Item item)
        {
            _purchaseContext.Items.Update(item);
            await _purchaseContext.SaveChangesAsync();
        }
    }
}
