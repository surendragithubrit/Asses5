﻿using Purchase_Order_Processing_System_POPS_.Entities;

namespace Purchase_Order_Processing_System_POPS_.Controllers
{
    public interface ISuppilerAsyncRepository
    {
        Task<List<SUPPLIER>> GetAll();
        Task<SUPPLIER> GetById(string id);
        Task Update(SUPPLIER supplier);
        Task DeleteById(string id);
        Task Add(SUPPLIER supplier);

    }
}
