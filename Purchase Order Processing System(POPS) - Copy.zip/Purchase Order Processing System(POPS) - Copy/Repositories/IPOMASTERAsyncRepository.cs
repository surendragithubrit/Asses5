﻿using Purchase_Order_Processing_System_POPS_.Entities;

namespace Purchase_Order_Processing_System_POPS_.Repositories
{
    public interface IPOMASTERAsyncRepository
    {
        Task<List<POMASTER>> GetAll();
        Task<POMASTER> GetById(string id);
        Task Update(POMASTER pOMASTER);
        Task DeleteById(string id);
        Task Add(POMASTER pOMASTER);
    }
}
