﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Purchase_Order_Processing_System_POPS_.Entities;
using Purchase_Order_Processing_System_POPS_.Repositories;
using System.Reflection.Emit;

namespace Purchase_Order_Processing_System_POPS_.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class POMASTERController : ControllerBase
    {
        private readonly IPOMASTERAsyncRepository _pomasterRepository;
        [HttpGet, Route("GetAllPurchases")]
        public async Task<IActionResult> GetAll()
        {
            return Ok(await _pomasterRepository.GetAll());
        }
        [HttpGet, Route("GetById/{id}")]
        public async Task<IActionResult> Get([FromRoute] string id)
        {
            return Ok(await _pomasterRepository.GetById(id));
        }

        [HttpPost, Route("AddPurchase")]

        public async Task<IActionResult> Add(POMASTER pOMASTER)
        {
            await _pomasterRepository.Add(pOMASTER);
            return Ok(pOMASTER);
        }

        [HttpPut, Route("Update")]
        public async Task<IActionResult> Edit(POMASTER pOMASTER)
        {
            await _pomasterRepository.Update(pOMASTER);
            return Ok(pOMASTER);
        }
        [HttpDelete, Route("Delete/{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            await _pomasterRepository.DeleteById(id);
            return Ok();
        }
    }
}
