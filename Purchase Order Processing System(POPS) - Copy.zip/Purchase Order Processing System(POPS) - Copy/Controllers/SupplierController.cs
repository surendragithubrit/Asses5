﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Purchase_Order_Processing_System_POPS_.Entities;

namespace Purchase_Order_Processing_System_POPS_.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SupplierController : ControllerBase
    {
        private readonly ISuppilerAsyncRepository _suppilerAsyncRepository;

        public SupplierController(ISuppilerAsyncRepository suppilerAsyncRepository)
        {
            _suppilerAsyncRepository = suppilerAsyncRepository;
        }

        [HttpGet, Route("GetAllSuppliers")]
        public async Task<IActionResult> GetAll()
        {
            return Ok(await _suppilerAsyncRepository.GetAll());
        }
        [HttpGet, Route("GetById/{id}")]
        public async Task<IActionResult> Get([FromRoute] string id)
        {
            return Ok(await _suppilerAsyncRepository.GetById(id));
        }

        [HttpPost, Route("AddSupplier")]
        public async Task<IActionResult> Add(SUPPLIER supplier)
        {
            await _suppilerAsyncRepository.Add(supplier);
            return Ok(supplier);
        }
        [HttpPut,Route("Edit")]
        public async Task<IActionResult> Edit(SUPPLIER supplier )
        {
            await _suppilerAsyncRepository.Update(supplier);
            return Ok(supplier);
        }
        [HttpDelete, Route("Delete/{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            await _suppilerAsyncRepository.DeleteById(id);
            return Ok();
        }
    }
}
