﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Purchase_Order_Processing_System_POPS_.Entities;
using Purchase_Order_Processing_System_POPS_.Repositories;

namespace Purchase_Order_Processing_System_POPS_.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ItemController : ControllerBase
    {
       private readonly IItemAsyncRepository _itemRepository;

        public ItemController(IItemAsyncRepository itemRepository)
        {
            _itemRepository = itemRepository;
        }

       

        [HttpGet, Route("GetAllItems")]
        public async Task<IActionResult> GetAll()
        {
            return Ok(await _itemRepository.GetAll());
        }
        [HttpGet, Route("GetById/{id}")]
        public async Task<IActionResult> Get([FromRoute] string id)
        {
            return Ok(await _itemRepository.GetById(id));
        }

        [HttpPost, Route("AddItem")]
        public async Task<IActionResult> Add(Item item)
        {
            await _itemRepository.Add(item);
            return Ok(item);
        }
        [HttpPut, Route("Edit")]
        public async Task<IActionResult> Edit(Item item)
        {
            await _itemRepository.Update(item);
            return Ok(item);
        }
        [HttpDelete, Route("Delete/{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            await _itemRepository.DeleteById(id);
            return Ok();
        }
    }
}
